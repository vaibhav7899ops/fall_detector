from flask import Flask, request, jsonify, send_from_directory
import pandas as pd
import joblib
import os

app = Flask(__name__)

# Load model once
MODEL_PATH = "custom_fall_risk_model.pkl"
DECISION_THRESHOLD = 0.3
FEATURE_NAMES = ['Distance', 'Pressure', 'HRV', 'Sugar level', 'SpO2', 'Accelerometer']

if not os.path.exists(MODEL_PATH):
    raise FileNotFoundError(f"Model file '{MODEL_PATH}' not found. Please train & save it first.")
model = joblib.load(MODEL_PATH)

def voice_alert(msg: str):
    """Speak alert with macOS `say`, or fallback to text."""
    if os.system("which say > /dev/null") == 0:
        safe = msg.replace('"', "'")
        os.system(f'say "{safe}"')
    else:
        print("[ALERT]", msg)

@app.route("/predict", methods=["POST"])
def predict():
    try:
        data = request.json
        if not data:
            return jsonify({"error": "No input received."}), 400

        # Validate keys
        missing = [f for f in FEATURE_NAMES if f not in data]
        if missing:
            return jsonify({"error": f"Missing features: {', '.join(missing)}"}), 400

        # Convert inputs to float
        try:
            values = [float(data[f]) for f in FEATURE_NAMES]
        except ValueError:
            return jsonify({"error": "All values must be valid numbers."}), 400

        # Prepare DataFrame
        row = pd.DataFrame([dict(zip(FEATURE_NAMES, values))])

        # Prediction
        pred_class = int(model.predict(row)[0])
        prob = None
        if hasattr(model, "predict_proba"):
            prob = float(model.predict_proba(row)[0][1])

        # Check alert condition
        is_alert = pred_class == 1 or (prob is not None and prob > DECISION_THRESHOLD)
        message = f"Alert: risk detected (class {pred_class}"
        if prob is not None:
            message += f", prob {prob:.2f}"
        message += ")"

        # Optionally do voice alert (backend-side)
        if is_alert:
            voice_alert(message)

        return jsonify({
            "input": dict(zip(FEATURE_NAMES, values)),
            "predicted_class": pred_class,
            "probability": round(prob, 2) if prob is not None else None,
            "alert": is_alert,
            "message": message if is_alert else "No alert: considered normal."
        })

    except Exception as e:
        return jsonify({"error": f"Internal server error: {str(e)}"}), 500

@app.route("/")
# def serve_frontend():
#     return send_from_directory("static", "index.html")

def health_check():
    return "Fall Risk Predictor API is running."

if __name__ == "__main__":
    app.run(debug=True)

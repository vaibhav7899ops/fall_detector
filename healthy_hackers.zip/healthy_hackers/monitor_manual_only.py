# monitor_cstick_threshold_adjusted.py

"""
Interactive fall‑risk predictor for custom cStick features:
  - Prompts user once for six sensor/vital values in comma‑separated format
  - Loads pretrained custom model and decision threshold
  - Predicts class and risk probability, alerts via macOS `say` or prints
  - Uses adjusted probability threshold of 0.3 for higher sensitivity
"""

import os
import sys
import pandas as pd
import joblib

# Path to your pretrained custom model
MODEL_PATH = "custom_fall_risk_model.pkl"
if not os.path.exists(MODEL_PATH):
    print(f"Model file '{MODEL_PATH}' not found. Please train & save it first.")
    sys.exit(1)

model = joblib.load(MODEL_PATH)
# Lowered decision threshold on probability for alert (for higher sensitivity)
DECISION_THRESHOLD = 0.3

# Feature names expected by the model
FEATURE_NAMES = ['Distance', 'Pressure', 'HRV', 'Sugar level', 'SpO2', 'Accelerometer']

def voice_alert(msg: str):
    """Speak alert with macOS `say`, or fall back to printing."""
    if os.system("which say > /dev/null") == 0:
        safe = msg.replace('"', "'")
        os.system(f'say "{safe}"')
    else:
        print("[ALERT]", msg)

def main():
    print("=== Custom cStick Predictor (Threshold=0.3) ===")
    print("Provide values in one line (comma‑separated):")
    print(", ".join(FEATURE_NAMES))
    print("Type 'exit' to quit.\n")

    raw = input("Enter values: ")
    if raw.strip().lower() in ("exit", "quit"):
        print("Exiting.")
        sys.exit(0)

    parts = [x.strip() for x in raw.split(",")]
    if len(parts) != len(FEATURE_NAMES):
        print(f"Invalid input. Please enter exactly {len(FEATURE_NAMES)} comma-separated values.")
        sys.exit(1)

    try:
        values = list(map(float, parts))
    except ValueError:
        print("All values must be valid numbers.")
        sys.exit(1)

    # Build feature DataFrame
    features = dict(zip(FEATURE_NAMES, values))
    row = pd.DataFrame([features])

    # Predict class
    pred_class = model.predict(row)[0]
    # Predict probability (if supported)
    prob = None
    if hasattr(model, "predict_proba"):
        prob = model.predict_proba(row)[0][1]

    # Output
    print(f"\nPredicted class: {pred_class}")
    if prob is not None:
        print(f"Predicted risk probability: {prob:.2f}")

    # Alert if risk class or prob above lowered threshold
    if pred_class == 1 or (prob is not None and prob > DECISION_THRESHOLD):
        msg = f"Alert: risk detected (class {pred_class}"
        if prob is not None:
            msg += f", prob {prob:.2f}"
        msg += ")"
        voice_alert(msg)
    else:
        print("No alert: considered normal.\n")

if __name__ == "__main__":
    main()
